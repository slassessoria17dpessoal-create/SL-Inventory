class Compartment < ApplicationRecord
  has_many :folders, dependent: :restrict_with_error

  validates :cabinet, presence: true
  validates :name, presence: true
  validates :width_cm, presence: true, numericality: { greater_than: 0 }

  # Returns the physical remaining space in centimeters
  def free_space(exclude_folder_id: nil)
    if folders.loaded?
      folders_to_sum = folders
      folders_to_sum = folders_to_sum.reject { |f| f.id == exclude_folder_id } if exclude_folder_id
      occupied = folders_to_sum.sum(&:thickness_cm)
    else
      occupied = folders.where.not(id: exclude_folder_id).sum(:thickness_cm)
    end
    [width_cm - occupied, 0.0].max
  end

  # Returns the occupancy percentage of the compartment
  def occupancy_percentage(exclude_folder_id: nil)
    return 0.0 if width_cm.zero?
    if folders.loaded?
      folders_to_sum = folders
      folders_to_sum = folders_to_sum.reject { |f| f.id == exclude_folder_id } if exclude_folder_id
      occupied = folders_to_sum.sum(&:thickness_cm)
    else
      occupied = folders.where.not(id: exclude_folder_id).sum(:thickness_cm)
    end
    ((occupied / width_cm) * 100.0).round(1)
  end

  # Returns the risk level color based on occupancy percentage
  # Green: 0% to 74% (Safe)
  # Yellow: 75% to 89% (Attention)
  # Red: 90% to 100% (Risk)
  def occupancy_color(exclude_folder_id: nil)
    pct = occupancy_percentage(exclude_folder_id:)
    if pct >= 90.0
      "red"
    elsif pct >= 75.0
      "yellow"
    else
      "green"
    end
  end

  # Suggests the best compartment with the largest available space for a folder of given thickness
  def self.suggest_for(thickness, exclude_folder_id: nil)
    all.select { |c| c.free_space(exclude_folder_id:) >= thickness }
       .max_by { |c| c.free_space(exclude_folder_id:) }
  end
end
