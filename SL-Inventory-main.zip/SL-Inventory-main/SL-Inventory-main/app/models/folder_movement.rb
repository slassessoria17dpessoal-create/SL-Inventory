class FolderMovement < ApplicationRecord
  validates :company_name, presence: true
  validates :action_type, presence: true, inclusion: { in: %w[create transfer destroy] }
  validates :thickness_cm, presence: true, numericality: { greater_than: 0 }

  def action_label
    case action_type
    when "create" then "Arquivada"
    when "transfer" then "Transferida"
    when "destroy" then "Retirada"
    else "Ação"
    end
  end
end

