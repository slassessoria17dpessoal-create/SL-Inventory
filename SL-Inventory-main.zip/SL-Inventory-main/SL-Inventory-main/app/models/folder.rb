class Folder < ApplicationRecord
  belongs_to :compartment

  validates :company_name, presence: true
  validates :thickness_cm, presence: true, inclusion: { in: [1.0, 3.0, 5.0, 7.0] }

  validate :compartment_has_enough_space

  after_create :log_creation
  before_update :log_transfer, if: :compartment_id_changed?
  after_destroy :log_destruction

  # T-Shirt sizing options and their corresponding thickness in cm
  SIZES = {
    "Fina" => 1.0,
    "Média" => 3.0,
    "Cheia" => 5.0,
    "Estourando" => 7.0
  }.freeze

  # Returns the visual name of the folder's size
  def size_name
    SIZES.key(thickness_cm) || "Personalizada"
  end

  private

  def compartment_has_enough_space
    return unless compartment && thickness_cm
    available = compartment.free_space(exclude_folder_id: id)
    if thickness_cm > available
      errors.add(:compartment_id, "não possui espaço suficiente (Disponível: #{available.round(1)} cm, Necessário: #{thickness_cm} cm)")
    end
  end

  def log_creation
    FolderMovement.create!(
      company_name: company_name,
      action_type: "create",
      to_compartment: "#{compartment.cabinet} – #{compartment.name}",
      thickness_cm: thickness_cm
    )
  end

  def log_transfer
    old_comp = Compartment.find_by(id: compartment_id_was)
    old_comp_name = old_comp ? "#{old_comp.cabinet} – #{old_comp.name}" : "Desconhecido"
    
    FolderMovement.create!(
      company_name: company_name,
      action_type: "transfer",
      from_compartment: old_comp_name,
      to_compartment: "#{compartment.cabinet} – #{compartment.name}",
      thickness_cm: thickness_cm
    )
  end

  def log_destruction
    comp_name = compartment ? "#{compartment.cabinet} – #{compartment.name}" : "Desconhecido"
    FolderMovement.create!(
      company_name: company_name,
      action_type: "destroy",
      from_compartment: comp_name,
      thickness_cm: thickness_cm
    )
  end
end

