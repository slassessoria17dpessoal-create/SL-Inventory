import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  connect() {
    // Smooth transition in
    requestAnimationFrame(() => {
      this.element.classList.remove("translate-y-2", "opacity-0")
    })

    // Auto-dismiss after 4 seconds
    this.timeout = setTimeout(() => {
      this.close()
    }, 4000)
  }

  disconnect() {
    clearTimeout(this.timeout)
  }

  close() {
    clearTimeout(this.timeout)
    
    // Smooth transition out
    this.element.classList.add("translate-y-2", "opacity-0")
    
    // Remove from DOM after transition completes
    this.element.addEventListener("transitionend", () => {
      this.element.remove()
    }, { once: true })
  }
}
