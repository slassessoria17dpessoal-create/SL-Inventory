import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static targets = [ "tab", "panel" ]

  connect() {
    this.handleResize()
    
    // Bind the listener and add to resize events
    this.boundResize = this.handleResize.bind(this)
    window.addEventListener("resize", this.boundResize)
  }

  disconnect() {
    window.removeEventListener("resize", this.boundResize)
  }

  switch(event) {
    if (this.isDesktop()) return
    
    event.preventDefault()
    const clickedTab = event.currentTarget
    const tabId = clickedTab.dataset.tabId

    this.setActiveTab(tabId)
  }

  handleResize() {
    if (this.isDesktop()) {
      // Ensure all panels are visible on desktop
      this.panelTargets.forEach(panel => {
        panel.classList.remove("hidden")
      })
    } else {
      // Re-apply correct visibility state on mobile
      const activeTab = this.tabTargets.find(tab => tab.classList.contains("border-indigo-500"))
      const tabId = activeTab ? activeTab.dataset.tabId : "folders"
      this.setActiveTab(tabId)
    }
  }

  setActiveTab(tabId) {
    this.tabTargets.forEach(tab => {
      if (tab.dataset.tabId === tabId) {
        tab.classList.add("text-indigo-400", "border-indigo-500", "bg-indigo-500/5")
        tab.classList.remove("text-slate-400", "border-transparent")
      } else {
        tab.classList.remove("text-indigo-400", "border-indigo-500", "bg-indigo-500/5")
        tab.classList.add("text-slate-400", "border-transparent")
      }
    })

    this.panelTargets.forEach(panel => {
      if (panel.dataset.panelId === tabId) {
        panel.classList.remove("hidden")
      } else {
        panel.classList.add("hidden")
      }
    })
  }

  isDesktop() {
    return window.innerWidth >= 1024
  }
}
