import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static targets = [ "content" ]

  toggle(event) {
    event.preventDefault()
    const content = this.contentTarget
    
    if (content.classList.contains("drawer-collapsed")) {
      content.classList.remove("drawer-collapsed")
      content.classList.add("drawer-expanded")
      this.element.classList.add("drawer-open")
    } else {
      content.classList.remove("drawer-expanded")
      content.classList.add("drawer-collapsed")
      this.element.classList.remove("drawer-open")
    }
  }
}
