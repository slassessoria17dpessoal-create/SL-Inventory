import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static targets = [ "form", "input" ]

  connect() {
    this.timeout = null
  }

  submit() {
    clearTimeout(this.timeout)
    
    // Debounce the submission to avoid database overload on every keystroke
    this.timeout = setTimeout(() => {
      // Rails requestSubmit() triggers standard form validation and submits via Turbo
      this.formTarget.requestSubmit()
    }, 250)
  }
}
