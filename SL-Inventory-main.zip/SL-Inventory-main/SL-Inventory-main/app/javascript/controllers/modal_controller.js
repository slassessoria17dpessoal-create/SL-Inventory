import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  connect() {
    this.boundKeydown = this.keydown.bind(this)
    window.addEventListener("keydown", this.boundKeydown)

    // Listen for turbo frame renders inside this modal to automatically open it
    this.boundFrameRender = this.handleFrameRender.bind(this)
    document.addEventListener("turbo:frame-render", this.boundFrameRender)

    // Listen for successful form submissions to automatically close it
    this.boundSubmitEnd = this.handleSubmitEnd.bind(this)
    document.addEventListener("turbo:submit-end", this.boundSubmitEnd)
  }

  disconnect() {
    window.removeEventListener("keydown", this.boundKeydown)
    document.removeEventListener("turbo:frame-render", this.boundFrameRender)
    document.removeEventListener("turbo:submit-end", this.boundSubmitEnd)
  }

  open() {
    this.element.classList.remove("hidden")
    document.body.classList.add("overflow-hidden")
  }

  close() {
    this.element.classList.add("hidden")
    document.body.classList.remove("overflow-hidden")
    
    // Clear frame content so old content doesn't flash when reopening
    const frame = this.element.querySelector("turbo-frame#modal-content")
    if (frame) {
      frame.innerHTML = ""
      frame.removeAttribute("src")
    }
  }

  handleFrameRender(event) {
    if (event.target.id === "modal-content") {
      if (event.target.innerHTML.trim() !== "") {
        this.open()
      }
    }
  }

  handleSubmitEnd(event) {
    // If the submission succeeded and the form was inside the modal, close the modal
    if (event.detail.success && this.element.contains(event.target)) {
      this.close()
    }
  }

  keydown(event) {
    if (event.key === "Escape") {
      this.close()
    }
  }
}
