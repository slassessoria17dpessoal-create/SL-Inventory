import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static targets = [ "thicknessInput", "compartmentSelect", "suggestionText" ]

  connect() {
    this.updateSuggestions()
  }

  updateSuggestions() {
    const thickness = parseFloat(this.thicknessInputTarget.value) || 3.0
    const select = this.compartmentSelectTarget
    const options = Array.from(select.options)

    let bestOption = null
    let maxFreeSpace = -1

    options.forEach(option => {
      // Don't modify the default blank option if present
      if (!option.value) return

      const freeSpace = parseFloat(option.dataset.freeSpace)
      const name = option.dataset.name

      if (freeSpace < thickness) {
        option.disabled = true
        option.textContent = `${name} (Sem espaço - ${freeSpace.toFixed(1)} cm livres)`
      } else {
        option.disabled = false
        option.textContent = `${name} (Livre: ${freeSpace.toFixed(1)} cm)`

        if (freeSpace > maxFreeSpace) {
          maxFreeSpace = freeSpace
          bestOption = option
        }
      }
    })

    // Update recommendation text
    if (bestOption) {
      this.suggestionTextTarget.textContent = `⭐ Recomendado: ${bestOption.dataset.name} (Livre: ${maxFreeSpace.toFixed(1)} cm)`
      this.suggestionTextTarget.classList.remove("hidden")
      this.suggestionTextTarget.classList.add("text-indigo-400")
      this.suggestionTextTarget.classList.remove("text-rose-400")

      // Auto-select the suggestion if the current selection is empty, or is disabled (no longer fits)
      const currentSelectedOption = select.selectedOptions[0]
      if (!select.value || (currentSelectedOption && currentSelectedOption.disabled)) {
        select.value = bestOption.value
      }
    } else {
      this.suggestionTextTarget.textContent = "⚠️ Nenhum compartimento possui espaço suficiente!"
      this.suggestionTextTarget.classList.remove("hidden")
      this.suggestionTextTarget.classList.add("text-rose-400")
      this.suggestionTextTarget.classList.remove("text-indigo-400")
    }
  }
}
