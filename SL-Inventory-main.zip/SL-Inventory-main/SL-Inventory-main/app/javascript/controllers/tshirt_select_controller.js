import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static targets = [ "button", "input" ]

  select(event) {
    event.preventDefault()
    const clickedBtn = event.currentTarget
    const val = clickedBtn.dataset.value

    this.inputTarget.value = val

    // Reset all buttons to default styling
    this.buttonTargets.forEach(btn => {
      btn.classList.remove("border-indigo-500", "bg-indigo-500/10", "ring-2", "ring-indigo-500/20")
      btn.classList.add("border-slate-800", "bg-slate-900/40")
      btn.querySelector(".check-icon")?.classList.add("hidden")
    })

    // Highlight clicked button
    clickedBtn.classList.add("border-indigo-500", "bg-indigo-500/10", "ring-2", "ring-indigo-500/20")
    clickedBtn.classList.remove("border-slate-800", "bg-slate-900/40")
    clickedBtn.querySelector(".check-icon")?.classList.remove("hidden")

    // Dispatch a change event on the hidden input so other controllers know it changed
    this.inputTarget.dispatchEvent(new Event("change"))
  }
}
