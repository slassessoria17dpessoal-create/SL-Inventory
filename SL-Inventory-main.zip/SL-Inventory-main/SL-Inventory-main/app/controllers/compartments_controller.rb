class CompartmentsController < ApplicationController
  before_action :set_compartment, only: %i[edit update destroy]

  def index
    @compartments = Compartment.includes(:folders).order(:cabinet, :name)
    @new_compartment = Compartment.new
  end

  def new
    @compartment = Compartment.new
  end

  def edit
  end

  def create
    @compartment = Compartment.new(compartment_params)

    respond_to do |format|
      if @compartment.save
        format.turbo_stream do
          render turbo_stream: [
            turbo_stream.replace("cabinets-heatmap", partial: "dashboard/cabinets_heatmap", locals: { cabinets: Compartment.includes(:folders).order(:cabinet, :name).group_by(&:cabinet) }),
            turbo_stream.replace("compartments-list", partial: "compartments/list", locals: { compartments: Compartment.includes(:folders).order(:cabinet, :name) }),
            turbo_stream.append("notifications", partial: "shared/toast", locals: { message: "Compartimento #{@compartment.cabinet} - #{@compartment.name} criado!", type: "success" }),
            turbo_stream.replace("new_compartment_modal", "")
          ]
        end
        format.html { redirect_to compartments_path, notice: "Compartimento criado com sucesso!" }
      else
        format.turbo_stream do
          render turbo_stream: turbo_stream.replace("compartment-form-errors", partial: "shared/form_errors", locals: { model: @compartment })
        end
        format.html { render :new, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @compartment.update(compartment_params)
        format.turbo_stream do
          render turbo_stream: [
            turbo_stream.replace("cabinets-heatmap", partial: "dashboard/cabinets_heatmap", locals: { cabinets: Compartment.includes(:folders).order(:cabinet, :name).group_by(&:cabinet) }),
            turbo_stream.replace("compartments-list", partial: "compartments/list", locals: { compartments: Compartment.includes(:folders).order(:cabinet, :name) }),
            turbo_stream.append("notifications", partial: "shared/toast", locals: { message: "Compartimento #{@compartment.cabinet} - #{@compartment.name} atualizado!", type: "success" }),
            turbo_stream.replace("edit_compartment_modal_#{@compartment.id}", "")
          ]
        end
        format.html { redirect_to compartments_path, notice: "Compartimento atualizado com sucesso!" }
      else
        format.turbo_stream do
          render turbo_stream: turbo_stream.replace("compartment-form-errors-#{@compartment.id}", partial: "shared/form_errors", locals: { model: @compartment })
        end
        format.html { render :edit, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    respond_to do |format|
      if @compartment.destroy
        format.turbo_stream do
          render turbo_stream: [
            turbo_stream.replace("cabinets-heatmap", partial: "dashboard/cabinets_heatmap", locals: { cabinets: Compartment.includes(:folders).order(:cabinet, :name).group_by(&:cabinet) }),
            turbo_stream.replace("compartments-list", partial: "compartments/list", locals: { compartments: Compartment.includes(:folders).order(:cabinet, :name) }),
            turbo_stream.append("notifications", partial: "shared/toast", locals: { message: "Compartimento excluído com sucesso!", type: "info" })
          ]
        end
        format.html { redirect_to compartments_path, notice: "Compartimento excluído com sucesso!" }
      else
        error_msg = @compartment.errors.full_messages.to_sentence
        format.turbo_stream do
          render turbo_stream: turbo_stream.append("notifications", partial: "shared/toast", locals: { message: "Erro ao excluir: #{error_msg}", type: "error" })
        end
        format.html { redirect_to compartments_path, alert: "Erro ao excluir: #{error_msg}" }
      end
    end
  end

  private

  def set_compartment
    @compartment = Compartment.find(params[:id])
  end

  def compartment_params
    params.require(:compartment).permit(:cabinet, :name, :width_cm)
  end
end
