class FoldersController < ApplicationController
  before_action :set_folder, only: %i[edit update destroy]
  before_action :set_compartments, only: %i[new edit create update]

  def new
    @folder = Folder.new
    # If a compartment is pre-selected
    if params[:compartment_id].present?
      @folder.compartment_id = params[:compartment_id]
    end
  end

  def edit
  end

  def create
    @folder = Folder.new(folder_params)

    respond_to do |format|
      if @folder.save
        format.turbo_stream do
          render turbo_stream: [
            turbo_stream.replace("cabinets-heatmap", partial: "dashboard/cabinets_heatmap", locals: { cabinets: Compartment.includes(:folders).order(:cabinet, :name).group_by(&:cabinet) }),
            turbo_stream.replace("folders-list", partial: "folders/list", locals: { folders: Folder.includes(:compartment).order(company_name: :asc) }),
            turbo_stream.append("notifications", partial: "shared/toast", locals: { message: "Pasta #{@folder.company_name} criada com sucesso!", type: "success" }),
            turbo_stream.replace("new_folder_modal", ""), # clear/close modal
            turbo_stream.replace("recent-activity", partial: "dashboard/recent_activity", locals: { movements: FolderMovement.order(created_at: :desc).limit(10) }),
            turbo_stream.replace("dashboard-stats", partial: "dashboard/stats", locals: { stats: dashboard_stats })
          ]
        end
        format.html { redirect_to root_path, notice: "Pasta criada com sucesso!" }
      else
        format.turbo_stream do
          render turbo_stream: turbo_stream.replace("folder-form-errors", partial: "shared/form_errors", locals: { model: @folder })
        end
        format.html { render :new, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @folder.update(folder_params)
        format.turbo_stream do
          render turbo_stream: [
            turbo_stream.replace("cabinets-heatmap", partial: "dashboard/cabinets_heatmap", locals: { cabinets: Compartment.includes(:folders).order(:cabinet, :name).group_by(&:cabinet) }),
            turbo_stream.replace("folders-list", partial: "folders/list", locals: { folders: Folder.includes(:compartment).order(company_name: :asc) }),
            turbo_stream.append("notifications", partial: "shared/toast", locals: { message: "Pasta #{@folder.company_name} atualizada com sucesso!", type: "success" }),
            turbo_stream.replace("edit_folder_modal_#{@folder.id}", ""),
            turbo_stream.replace("recent-activity", partial: "dashboard/recent_activity", locals: { movements: FolderMovement.order(created_at: :desc).limit(10) }),
            turbo_stream.replace("dashboard-stats", partial: "dashboard/stats", locals: { stats: dashboard_stats })
          ]
        end
        format.html { redirect_to root_path, notice: "Pasta atualizada com sucesso!" }
      else
        format.turbo_stream do
          render turbo_stream: turbo_stream.replace("folder-form-errors-#{@folder.id}", partial: "shared/form_errors", locals: { model: @folder })
        end
        format.html { render :edit, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    company_name = @folder.company_name
    @folder.destroy

    respond_to do |format|
      format.turbo_stream do
        render turbo_stream: [
          turbo_stream.replace("cabinets-heatmap", partial: "dashboard/cabinets_heatmap", locals: { cabinets: Compartment.includes(:folders).order(:cabinet, :name).group_by(&:cabinet) }),
          turbo_stream.replace("folders-list", partial: "folders/list", locals: { folders: Folder.includes(:compartment).order(company_name: :asc) }),
          turbo_stream.append("notifications", partial: "shared/toast", locals: { message: "Pasta #{company_name} excluída com sucesso!", type: "info" }),
          turbo_stream.replace("recent-activity", partial: "dashboard/recent_activity", locals: { movements: FolderMovement.order(created_at: :desc).limit(10) }),
          turbo_stream.replace("dashboard-stats", partial: "dashboard/stats", locals: { stats: dashboard_stats })
        ]
      end
      format.html { redirect_to root_path, notice: "Pasta excluída com sucesso!" }
    end
  end

  private

  def set_folder
    @folder = Folder.find(params[:id])
  end

  def set_compartments
    @compartments = Compartment.includes(:folders).order(:cabinet, :name)
  end

  def folder_params
    params.require(:folder).permit(:company_name, :compartment_id, :thickness_cm)
  end
end
