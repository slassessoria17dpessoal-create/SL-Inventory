require "csv"

class DashboardController < ApplicationController
  def index
    @folders = Folder.includes(:compartment).order(company_name: :asc)
    
    if params[:query].present?
      @folders = @folders.where("company_name ILIKE ?", "%#{params[:query]}%")
    end

    @cabinets = Compartment.includes(:folders).order(:cabinet, :name).group_by(&:cabinet)
    @new_folder = Folder.new
    @new_compartment = Compartment.new
    @movements = FolderMovement.order(created_at: :desc).limit(10)
  end


  def export_csv
    @folders = Folder.includes(:compartment).order("compartments.cabinet ASC, compartments.name ASC, folders.company_name ASC")

    csv_data = "\xEF\xBB\xBF" + CSV.generate(headers: true, col_sep: ";", write_headers: true) do |csv|
      csv << ["Armário", "Gaveta/Prateleira", "Capacidade da Gaveta (cm)", "Espaço Livre (cm)", "Empresa", "Espessura da Pasta (cm)", "Tamanho da Pasta"]

      @folders.each do |folder|
        csv << [
          folder.compartment.cabinet,
          folder.compartment.name,
          folder.compartment.width_cm,
          folder.compartment.free_space.round(1),
          folder.company_name,
          folder.thickness_cm,
          folder.size_name
        ]
      end
    end

    send_data csv_data, filename: "sl-inventory-relatorio-#{Date.today}.csv", type: "text/csv; charset=utf-8"
  end
end

