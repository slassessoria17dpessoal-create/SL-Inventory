class SessionsController < ApplicationController
  skip_before_action :require_login, only: [:new, :create]

  OPERATOR_USERNAME = "Operador@SL"
  OPERATOR_PASSWORD_HASH = '$2a$12$kyVXEUhfM6pbJLfzPvFLOeTtd7r21TxZnL0wXbMCyN.hicJfupE8m'

  def new
    redirect_to root_path if logged_in?
  end

  def create
    username = params[:username]
    password = params[:password]

    if authenticate(username, password)
      # Reset session to prevent session fixation attacks
      reset_session
      session[:operator_logged_in] = true
      redirect_to root_path, status: :see_other, notice: "Login efetuado com sucesso!"
    else
      flash.now[:alert] = "Usuário ou senha inválidos."
      render :new, status: :unprocessable_entity
    end
  end

  def destroy
    reset_session
    redirect_to login_path, status: :see_other, notice: "Sessão encerrada com sucesso."
  end

  private

  def authenticate(username, password)
    return false unless username == OPERATOR_USERNAME
    return false if password.blank?

    begin
      bcrypt_pwd = BCrypt::Password.new(OPERATOR_PASSWORD_HASH)
      bcrypt_pwd == password
    rescue BCrypt::Errors::InvalidHash
      false
    end
  end
end
