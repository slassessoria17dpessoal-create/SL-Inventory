class ApplicationController < ActionController::Base
  # Only allow modern browsers supporting webp images, web push, badges, import maps, CSS nesting, and CSS :has.
  allow_browser versions: :modern

  # Changes to the importmap will invalidate the etag for HTML responses
  stale_when_importmap_changes

  before_action :require_login

  helper_method :logged_in?
  helper_method :dashboard_stats

  private

  def logged_in?
    session[:operator_logged_in] == true
  end

  def require_login
    unless logged_in?
      if request.headers["HTTP_TURBO_FRAME"].present?
        # Force full-page redirect when session expires during a Turbo Frame interaction
        render html: "<script>window.top.location.href = '#{login_url}'</script>".html_safe
      else
        redirect_to login_path, status: :see_other, alert: "Acesso restrito. Por favor, faça login."
      end
    end
  end

  def dashboard_stats
    cabinets = Compartment.includes(:folders).to_a
    total_folders = Folder.count
    total_capacity = cabinets.sum(&:width_cm)
    total_occupied = Folder.sum(:thickness_cm)
    global_occupancy = total_capacity.zero? ? 0.0 : ((total_occupied / total_capacity) * 100.0).round(1)
    
    critical_count = cabinets.count { |c| c.occupancy_percentage >= 90.0 }
    emptiest_compartment = cabinets.max_by(&:free_space)

    {
      total_folders: total_folders,
      total_capacity: total_capacity,
      total_occupied: total_occupied,
      global_occupancy: global_occupancy,
      critical_count: critical_count,
      emptiest_compartment: emptiest_compartment
    }
  end

end
