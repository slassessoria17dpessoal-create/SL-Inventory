# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_06_01_124744) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "compartments", force: :cascade do |t|
    t.string "cabinet", null: false
    t.datetime "created_at", null: false
    t.string "name", null: false
    t.datetime "updated_at", null: false
    t.float "width_cm", null: false
  end

  create_table "folder_movements", force: :cascade do |t|
    t.string "action_type", null: false
    t.string "company_name", null: false
    t.datetime "created_at", null: false
    t.string "from_compartment"
    t.float "thickness_cm", null: false
    t.string "to_compartment"
    t.datetime "updated_at", null: false
  end

  create_table "folders", force: :cascade do |t|
    t.string "company_name", null: false
    t.bigint "compartment_id", null: false
    t.datetime "created_at", null: false
    t.float "thickness_cm", null: false
    t.datetime "updated_at", null: false
    t.index ["compartment_id"], name: "index_folders_on_compartment_id"
  end

  add_foreign_key "folders", "compartments"
end
