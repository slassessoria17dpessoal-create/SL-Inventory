require "test_helper"

class DashboardControllerTest < ActionDispatch::IntegrationTest
  setup do
    # Create test data
    @compartment = Compartment.create!(
      cabinet: "Armário de Teste",
      name: "Gaveta 1",
      width_cm: 50.0
    )
    @folder = Folder.create!(
      company_name: "Empresa de Teste",
      compartment: @compartment,
      thickness_cm: 3.0
    )
  end

  test "should redirect export_csv to login when not logged in" do
    get export_csv_path
    assert_redirected_to login_path
  end

  test "should export csv when logged in" do
    # Stub ApplicationController#logged_in? to bypass authentication in this test
    ApplicationController.stub_instance_method(:logged_in?, true) do
      get export_csv_path
      assert_response :success
      assert_equal "text/csv; charset=utf-8", response.content_type

      # Verify CSV headers and content
      csv_content = response.body
      assert csv_content.start_with?("\xEF\xBB\xBF") # Check UTF-8 BOM
      
      # Clean BOM for parsing
      clean_csv = csv_content.delete_prefix("\xEF\xBB\xBF")
      
      # Verify headers
      headers = "Armário;Gaveta/Prateleira;Capacidade da Gaveta (cm);Espaço Livre (cm);Empresa;Espessura da Pasta (cm);Tamanho da Pasta"
      assert_includes clean_csv, headers

      # Verify row data
      expected_row = "Armário de Teste;Gaveta 1;50.0;47.0;Empresa de Teste;3.0;Média"
      assert_includes clean_csv, expected_row
    end
  end
end

# Simple helper for stubbing instance methods in testing
class Class
  def stub_instance_method(method_name, return_value)
    old_method = instance_method(method_name) rescue nil
    define_method(method_name) { return_value }
    yield
  ensure
    if old_method
      define_method(method_name, old_method)
    else
      remove_method(method_name) rescue nil
    end
  end
end
