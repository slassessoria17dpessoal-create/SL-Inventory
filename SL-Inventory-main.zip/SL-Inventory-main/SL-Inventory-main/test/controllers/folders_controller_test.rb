require "test_helper"

class FoldersControllerTest < ActionDispatch::IntegrationTest
  setup do
    # Stub ApplicationController#logged_in? to bypass authentication in this test
    ApplicationController.stub_instance_method(:logged_in?, true) do
      @compartment = Compartment.create!(
        cabinet: "Armário Principal",
        name: "Gaveta 1",
        width_cm: 60.0
      )
      @folder = Folder.create!(
        company_name: "Original Corp",
        compartment: @compartment,
        thickness_cm: 3.0
      )
    end
  end

  test "should create folder and render recent-activity turbo stream" do
    ApplicationController.stub_instance_method(:logged_in?, true) do
      assert_difference "Folder.count", 1 do
        post folders_path, params: {
          folder: {
            company_name: "Nova Empresa",
            compartment_id: @compartment.id,
            thickness_cm: 3.0
          }
        }, as: :turbo_stream
      end

      assert_response :success
      assert_match /turbo-stream action="replace" target="recent-activity"/, response.body
      assert_match /turbo-stream action="replace" target="dashboard-stats"/, response.body
      assert_match /Nova Empresa/, response.body
    end
  end

  test "should update folder and render recent-activity turbo stream" do
    new_comp = Compartment.create!(
      cabinet: "Armário Secundário",
      name: "Gaveta A",
      width_cm: 50.0
    )

    ApplicationController.stub_instance_method(:logged_in?, true) do
      patch folder_path(@folder), params: {
        folder: {
          compartment_id: new_comp.id
        }
      }, as: :turbo_stream

      assert_response :success
      assert_match /turbo-stream action="replace" target="recent-activity"/, response.body
      assert_match /turbo-stream action="replace" target="dashboard-stats"/, response.body
    end
  end

  test "should destroy folder and render recent-activity turbo stream" do
    ApplicationController.stub_instance_method(:logged_in?, true) do
      assert_difference "Folder.count", -1 do
        delete folder_path(@folder), as: :turbo_stream
      end

      assert_response :success
      assert_match /turbo-stream action="replace" target="recent-activity"/, response.body
      assert_match /turbo-stream action="replace" target="dashboard-stats"/, response.body
    end
  end
end
