require "test_helper"

class FolderMovementTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
