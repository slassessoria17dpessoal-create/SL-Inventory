require "test_helper"

class FolderTest < ActiveSupport::TestCase
  setup do
    @comp1 = Compartment.create!(
      cabinet: "Armário de Aço",
      name: "Gaveta 1",
      width_cm: 50.0
    )
    @comp2 = Compartment.create!(
      cabinet: "Armário de Madeira",
      name: "Prateleira 2",
      width_cm: 60.0
    )
  end

  test "creating a folder should generate a create movement log" do
    assert_difference "FolderMovement.count", 1 do
      Folder.create!(
        company_name: "Empresa Alfa",
        compartment: @comp1,
        thickness_cm: 3.0
      )
    end

    movement = FolderMovement.last
    assert_equal "Empresa Alfa", movement.company_name
    assert_equal "create", movement.action_type
    assert_equal "Armário de Aço – Gaveta 1", movement.to_compartment
    assert_nil movement.from_compartment
    assert_equal 3.0, movement.thickness_cm
  end

  test "transferring a folder should generate a transfer movement log" do
    folder = Folder.create!(
      company_name: "Empresa Beta",
      compartment: @comp1,
      thickness_cm: 3.0
    )

    assert_difference "FolderMovement.count", 1 do
      folder.update!(compartment: @comp2)
    end

    movement = FolderMovement.last
    assert_equal "Empresa Beta", movement.company_name
    assert_equal "transfer", movement.action_type
    assert_equal "Armário de Aço – Gaveta 1", movement.from_compartment
    assert_equal "Armário de Madeira – Prateleira 2", movement.to_compartment
    assert_equal 3.0, movement.thickness_cm
  end

  test "destroying a folder should generate a destroy movement log" do
    folder = Folder.create!(
      company_name: "Empresa Gama",
      compartment: @comp1,
      thickness_cm: 3.0
    )

    assert_difference "FolderMovement.count", 1 do
      folder.destroy
    end

    movement = FolderMovement.last
    assert_equal "Empresa Gama", movement.company_name
    assert_equal "destroy", movement.action_type
    assert_equal "Armário de Aço – Gaveta 1", movement.from_compartment
    assert_nil movement.to_compartment
    assert_equal 3.0, movement.thickness_cm
  end
end
